# RAI > 2025-02-13 6:45pm
https://universe.roboflow.com/month-you/rai-eal4s

Provided by a Roboflow user
License: CC BY 4.0

